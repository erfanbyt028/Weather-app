import React from "react";
import { FaMoon } from "react-icons/fa";
import { LuArrowBigDown } from "react-icons/lu";

const moonPhases = [
  "311", // New Moon
  "312", // Waxing Crescent
  "313", // First Quarter
  "314", // Waxing Gibbous
  "315", // Full Moon
  "316", // Waning Gibbous
  "317", // Last Quarter
  "318", // Waning Crescent
];

// الگوریتم ساده برای تعیین فاز ماه بر اساس تاریخ فعلی
function getMoonPhase() {
  let now = new Date();
  let year = now.getFullYear();
  let month = now.getMonth() + 1;
  let day = now.getDate();
  // الگوریتم تقریبی (Meeus)
  let c = 0;
  let e = 0;
  let jd = 0;
  let b = 0;
  if (month < 3) {
    year--;
    month += 12;
  }
  ++month;
  c = 365.25 * year;
  e = 30.6 * month;
  jd = c + e + day - 694039.09; // jd is total days elapsed
  jd /= 29.5305882; // divide by the moon cycle
  b = parseInt(jd); // int(jd) -> b, take integer part of jd
  jd -= b; // subtract integer part to leave fractional part of original jd
  b = Math.round(jd * 8); // scale fraction from 0-8 and round
  if (b >= 8 ) b = 0; // 0 and 8 are the same phase
  return b;
}

const activeIndex = getMoonPhase();

const MoonPhase = () => {
  return (
    <div className="w-full max-w-xs h-40 sm:h-56 p-3 sm:p-4 rounded-2xl bg-white/10 backdrop-blur-sm text-white flex flex-col justify-between shadow-lg">
      <div className="flex items-center gap-2 text-xs sm:text-sm font-medium">
        <FaMoon className="text-yellow-300" size={18} />
        <span>Moon Phase</span>
      </div>
      <div className="flex flex-col items-center">
        <div className="text-3xl sm:text-5xl">{String.fromCodePoint(parseInt(moonPhases[activeIndex], 16))}</div>
        <LuArrowBigDown className="text-white mt-1 animate-bounce" />
      </div>
      <div className="relative mt-2">
        <svg className="absolute top-0 left-0 w-full h-10 sm:h-16" viewBox="0 0 320 64" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M10 40 C 60 10, 120 10, 160 40 S 260 70, 310 40"
            stroke="#fff6"
            strokeWidth="2"
            fill="none"
            strokeLinecap="round"
          />
        </svg>
        <div className="flex justify-between items-end px-2 mt-8 sm:mt-14">
          {moonPhases.map((icon, i) => (
            <div
              key={i}
              className={`text-base sm:text-xl transition-all ${
                i === activeIndex ? "scale-125 text-white drop-shadow" : "opacity-70"
              }`}
            >
              {String.fromCodePoint(parseInt(icon, 16))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MoonPhase;
