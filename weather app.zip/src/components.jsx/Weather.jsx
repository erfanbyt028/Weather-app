import React, { useState, useEffect } from "react";
import Info from "./Info";
import WeatherIcon from "./WeatherIcon";
import bgWeather from "../assets/images/bg-weather.png";
import Indoor from "./Indoor";
import Barometer from "./Barometer";
import MoonPhase from "./MoonPhase";
import Chart from "./Chart";
import AirConditions from "./AirConditions";
import { fetchWeather, fetchForecast } from "../api/weather";

const Weather = () => {
  const [background, setBackground] = useState(bgWeather);
  const [weatherData, setWeatherData] = useState(null);
  const [forecastData, setForecastData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const city = "New York";

  useEffect(() => {
    setLoading(true);
    setError(null);
    Promise.all([
      fetchWeather(city),
      fetchForecast(city)
    ])
      .then(([weather, forecast]) => {
        setWeatherData(weather);
        setForecastData(forecast);
        setLoading(false);
        if (weather.weather && weather.weather[0].main === "Snow") setBackground(bgWeather); // می‌توانی عکس‌های مختلف بزاری
        else setBackground(bgWeather);
        console.log('weatherData:', weather);
        console.log('forecastData:', forecast);
      })
      .catch((err) => {
        setError(err.message || "Failed to fetch weather data");
        setLoading(false);
      });
  }, [city]);

  if (loading) return <div className="text-white text-center mt-20">Loading...</div>;
  if (error) return <div className="text-red-400 text-center mt-20">{error}</div>;

  if (!weatherData || !forecastData || !weatherData.weather || !weatherData.main) {
    return <div className="text-white text-center mt-20">No weather data available.</div>;
  }

  return (
    <div
      className="w-full min-h-screen bg-cover bg-center bg-no-repeat text-white"
      style={{ backgroundImage: `url(${background})` }}
    >
      <div className="w-full max-w-7xl mx-auto px-4 py-8 grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="md:col-span-2 flex flex-col justify-between">
          <Info
            city={weatherData.name || "-"}
            weather={weatherData.weather[0]?.main || "-"}
            temp={weatherData.main.temp ? Math.round(weatherData.main.temp) : "-"}
            date={new Date().toLocaleString()}
          />
        </div>
        <div className="md:col-span-2 flex items-center justify-center">
          <WeatherIcon weather={weatherData.weather[0]?.main || "Clear"} />
        </div>
        <div className="md:col-span-1 flex items-center justify-center">
          <Indoor temp={weatherData.main.temp ? Math.round(weatherData.main.temp) : "-"} humidity={weatherData.main.humidity || "-"} />
        </div>
        <div className="md:col-span-1 flex items-center justify-center">
          <Barometer pressure={weatherData.main.pressure || "-"} />
        </div>
        <div className="md:col-span-1 flex items-center justify-center">
          <MoonPhase />
        </div>
        <div className="md:col-span-1 md:row-span-2 flex">
          <AirConditions
            wind={weatherData.wind?.speed || "-"}
            realFeel={weatherData.main.feels_like ? Math.round(weatherData.main.feels_like) : "-"}
            rain={weatherData.rain ? weatherData.rain["1h"] : 0}
            uv={4} 
            forecast={forecastData}
          />
        </div>
        <div className="md:col-span-3 w-full flex justify-center items-end">
          <Chart forecast={forecastData} />
        </div>
      </div>
    </div>
  );
};

export default Weather;
