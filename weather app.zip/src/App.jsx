import './App.css'
import Weather from './components.jsx/weather'

function App() {

  return (
    <>
      <Weather/>
    </>
  )
}

export default App
